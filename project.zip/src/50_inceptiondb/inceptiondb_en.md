# InceptionDB

This is inceptiondb in markdown

## What is InceptionDB

InceptionDB is a nosql database to store JSON documents

## The benefit